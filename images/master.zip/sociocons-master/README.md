SocioCons
=========

Designed and Created By: Rohit Tripathi. &copy; <a href="http://rohitink.com/sociocons">rohitink.com</a> 2013.

SocioCons are a set of Social Network and Sharing icons, which are completely open source, free to use for personal or commercial applications without having the need to give credits.


SocioCons were initially created in vector format. So, you can use them to generate images of any size without distorting the quality. Sociocons are best suited for hdpi and retina display devices.

<<<<<<< HEAD
More Details about Sociocons is available at http://rohitink.com/sociocons/
=======
More Details about Sociocons is available at http://rohitink.com/sociocons/
>>>>>>> 79d054dc5a76ee40a55b546bb43aa33c2eb70d08
